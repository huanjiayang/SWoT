#ifndef  UART_H_INCLUDED
#define  UART_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

#include <jendefs.h>

#define UART_JENOS        		TRUE	/**< Compile for JenOs */

PUBLIC bool_t vUART_Init(uint8 u8Uart,	/**< Uart to open */
						uint32    	   u32BaudRate,		/**< Baud rate */
						bool_t   	     bEvenParity,	/**< Even parity */
						bool_t   	     bEnableParity,	/**< Enable parity */
						uint8      	    u8WordLength,	/**< Word length, one of:\n
											 	 E_AHI_UART_WORD_LEN_5\n
											 	 E_AHI_UART_WORD_LEN_6\n
											 	 E_AHI_UART_WORD_LEN_7\n
											 	 E_AHI_UART_WORD_LEN_8 */
						bool_t   	     bOneStopBit);	/**< One stop bit */
PUBLIC void vUART_StartTx(void);
PUBLIC void vUART_RxCharISR(uint8 u8RxChar);
PUBLIC void UART_bPutChar (char cChar);
PUBLIC void vUART_TxCharISR(uint8 u8Uart);
PUBLIC 	bool_t writeData(const char     *pcFormat, ...);
PUBLIC 	bool_t UART_bPrintf_ap (const char     *pcFormat,	va_list  ap);



#if defined __cplusplus
}
#endif

#endif  /* UART_H_INCLUDED */
