
#include <jendefs.h>
#include "os.h"
#include "os_gen.h"
#include "pwrm.h"
#include "AppHardwareApi.h"

PRIVATE volatile uint32 s_u32CompareTime = 0;
PRIVATE volatile uint32 s_u32LastExpiredTime = 0;


OS_HWCOUNTER_ENABLE_CALLBACK(APP_cbEnableTickTimer)
{
    vAHI_TickTimerIntEnable(FALSE);
    vAHI_TickTimerConfigure(E_AHI_TICK_TIMER_CONT);
    vAHI_TickTimerIntPendClr();
    vAHI_TickTimerIntEnable(TRUE);

    PWRM_eStartActivity();
}

/****************************************************************************/

OS_HWCOUNTER_DISABLE_CALLBACK(APP_cbDisableTickTimer)
{
    vAHI_TickTimerIntEnable(FALSE);
    vAHI_TickTimerConfigure(E_AHI_TICK_TIMER_DISABLE);

    PWRM_eFinishActivity();
}

/****************************************************************************/

OS_HWCOUNTER_GET_CALLBACK(APP_cbGetTickTimer)
{
    return u32AHI_TickTimerRead();
}

/****************************************************************************/

OS_HWCOUNTER_SET_CALLBACK(APP_cbSetTickTimerCompare, u32CompareValue)
{
    /* calculations are relative to the last compare register value to account for counter wrap around */
    uint32 u32NextDelta = u32CompareValue - s_u32LastExpiredTime;
    uint32 u32CurDelta = u32AHI_TickTimerRead() - s_u32LastExpiredTime;

    /*
     * Race condition here. If the tick counter has incremented passed the compare point
     * in the time between reading it and loading the compare register the interrupt will be missed.
     * Increase the delta to take account of this time. To minimise this time, the number of
     * instructions between the register read and write to the interval register should be minimised.
     */
    u32CurDelta += 24;

    if (u32CurDelta < u32NextDelta)
    {
        vAHI_TickTimerInterval(u32CompareValue);
        s_u32CompareTime = u32CompareValue;
        return TRUE;
    }

    return FALSE;
}

/****************************************************************************
 *
 * NAME: TickInterrupt
 *
 * DESCRIPTION:
 * Interrupt service routine which is invoked by the tick timer when the
 * counter value matches the compare register value
 *
 ****************************************************************************/
OS_ISR(APP_isrTickTimer)
{
    vAHI_TickTimerIntPendClr();

    /*
     * compare register is only 28bits wide so make sure the upper 4bits match
     * the set compare point
     */
    uint32 u32Delta = u32AHI_TickTimerRead() - s_u32CompareTime;
    if (0 == (u32Delta >> 28))
    {
        uint32 u32Temp = s_u32CompareTime;
        OS_eExpireSWTimers(APP_cntrTickTimer);
        s_u32LastExpiredTime = u32Temp;
    }
}

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/

