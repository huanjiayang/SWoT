#ifndef  SERIAL_Q_H_INCLUDED
#define  SERIAL_Q_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

#include <jendefs.h>

typedef enum {RX_QUEUE = 0, TX_QUEUE } eQueueRef;

PUBLIC void   vSerialQ_Init(void);
PUBLIC bool_t bSerialQ_Full(eQueueRef eQueue);
PUBLIC bool_t bSerialQ_Empty(eQueueRef eQueue);
PUBLIC uint8  u8SerialQ_RemoveItem(eQueueRef eQueue);
PUBLIC void   vSerialQ_AddItem(eQueueRef eQueue, uint8 u8Item);
PUBLIC void vSerialQ_Flush(eQueueRef eQueue);


#if defined __cplusplus
}
#endif

#endif  /* SERIAL_Q_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


