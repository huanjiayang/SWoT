#ifndef APP_LOG_H_
#define APP_LOG_H_

/* length of log history */
#define APP_LOG_HISTORY_LEN     (16UL)
#define NOT_FOUND               0xff

/* Holds all stored data for a particular sensor for a node */
typedef struct
{
    uint8 u8NowValue;
    uint8 au8GraphData[APP_LOG_HISTORY_LEN];
} APP_tsLogSensorData;

/* Holds all stored data for a node */
typedef struct
{
    uint16 u16ShortAddr;
    uint8 u8FramesMissed;
    uint8 u8SwitchOn;
    uint64 u8aRfidTagid[13];
     APP_tsLogSensorData asNodeSensorData[APP_HSDEMO_NUM_SENSOR_TYPES];
} APP_tsLogNodeHistory;

/****************************************************************************/

PUBLIC void APP_vLogInitialise(void);
PUBLIC void APP_vLogStart(void);
PUBLIC APP_tsLogNodeHistory *APP_psLogGetSensorNodeHistory(uint8 u8SensorNode);
PUBLIC uint8 APP_u8LogGetDataStartPos(void);
PUBLIC uint8 APP_u8GetSensorNodeId(uint16 u16ShortAddr, uint64 u64IeeeAddress);
PUBLIC uint16 APP_u16GetSensorNodeAddr(uint8 u8Node);
PUBLIC uint8 APP_u8ControllerNodeNumDataSensors(void);

/****************************************************************************/


#endif /*APP_LOG_H_*/
