#ifndef APP_HOME_SENSOR_DEMO_H_
#define APP_HOME_SENSOR_DEMO_H_

/****************************************************************************/


#define APP_HSDEMO_NUM_SENSORNODES                  4
#define APP_HSDEMO_NUM_SENSORNODES_POSITIONS        4
#define APP_HSDEMO_NUM_SENSOR_TYPES                 3

/****************************************************************************/


typedef enum
{
    APP_E_SENSOR_TEMP = 0,
    APP_E_SENSOR_HTS,
    APP_E_SENSOR_ALS,
  } APP_teSensor;

typedef enum
{
    APP_E_EVENT_NONE = 0,
    APP_E_EVENT_BUTTON_UP,
    APP_E_EVENT_BUTTON_DOWN
} APP_teEventType;

typedef struct
{
    uint8 u8Button;
} APP_teEventButton;

typedef struct
{
    APP_teEventType eType;
    union
    {
        APP_teEventButton sButton;
    };
} APP_tsEvent;

typedef struct
{
    uint8 u8Length;
    uint64 u64ExtAddr;
    uint8 u8LightValue;
    uint8 u8TempValue;
    uint8 u8HumidityValue;
    uint8 u8Switch;
    uint8 u8aRfidTag[13];
} APP_tsSensorData;
//structure to receive sensor data from APDU

#define APDU_SENSORDATA_LENGTH      0
#define APDU_SENSORDATA_ADDR        1
#define APDU_SENSORDATA_LIGHT       9
#define APDU_SENSORDATA_TEMP        10
#define APDU_SENSORDATA_HUMIDITY    11
#define APDU_SENSORDATA_SWITCH      12
#define APDU_SENSORDATA_RFID		13

#define APDU_LEDCTRL_LENGTH     0
#define APDU_LEDCTRL_ADDR       1
#define APDU_LEDCTRL_STATE      9

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        External Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

#endif /*APP_HOME_SENSOR_DEMO_H_*/
