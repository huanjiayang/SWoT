#include <jendefs.h>
#include <AppHardwareApi.h>
#include <os.h>
#include "os_gen.h"


#include "serial.h"
#include "serialq.h"
#include "uart.h"
#include "ledcontrol.h"
#include "app_led.h"
#include "dbg.h"



PRIVATE bool_t	Uart_Opened[2];

PRIVATE void UART_vInterrupt(uint32 u32Device, uint32 u32ItemBitmap);
PRIVATE bool_t UART_bPad2Min(uint8 u8Width, uint8 u8Min, char cPad);
PRIVATE bool_t UART_bNum2String(uint32 u32Number, uint8 u8Base, uint8 u8Min, char cPad, bool_t bLeft, char cSign, bool_t bPrefix);

PUBLIC bool_t vUART_Init(uint8 u8Uart,	/**< Uart to open */
		uint32    	   u32BaudRate,		/**< Baud rate */
		bool_t   	     bEvenParity,	/**< Even parity */
		bool_t   	     bEnableParity,	/**< Enable parity */
		uint8      	    u8WordLength,	/**< Word length, one of:\n
										 	 E_AHI_UART_WORD_LEN_5\n
										 	 E_AHI_UART_WORD_LEN_6\n
										 	 E_AHI_UART_WORD_LEN_7\n
										 	 E_AHI_UART_WORD_LEN_8 */
		bool_t   	     bOneStopBit)	/**< One stop bit */
{
	uint16 	  u16Divisor;		/* Baud rate divisor */
	uint32 	  u32Remainder;		/* Baud rate remainder */

/* Valid uart ? */
	if (u8Uart < 2)
	{
		/* Calculate divisor for baud rate = 16MHz / (16 x baud rate) */
		u16Divisor   = (uint16)(16000000UL / (16UL * u32BaudRate));
		/* Correct for rounding errors */
		u32Remainder = (uint32)(16000000UL % (16UL * u32BaudRate));
		if (u32Remainder >= ((16UL * u32BaudRate) / 2)) u16Divisor += 1;

		/* Start with port unopened */
		Uart_Opened[u8Uart]= FALSE;
		vAHI_UartSetRTSCTS(u8Uart, FALSE);


		/* Enable UART 0 */
		vAHI_UartEnable(u8Uart);

		vAHI_UartReset(u8Uart, TRUE, TRUE);
		vAHI_UartReset(u8Uart, FALSE, FALSE);

		Uart_Opened[u8Uart]= TRUE;


		#if !UART_JENOS
		{
			/* Register function that will handle UART interrupts */
			if (u8Uart == E_AHI_UART_0) vAHI_Uart0RegisterCallback(UART_vInterrupt);
			if (u8Uart == E_AHI_UART_1) vAHI_Uart1RegisterCallback(UART_vInterrupt);
		}
		#endif
		/* Set baud rate */
		vAHI_UartSetBaudDivisor(u8Uart, u16Divisor);

		/* Set control */
		vAHI_UartSetControl(u8Uart, bEvenParity, bEnableParity, u8WordLength, bOneStopBit, FALSE);
		/* Set UART interrupts */
		vAHI_UartSetInterrupt(u8Uart,
							  FALSE, 		  				  /* ModemStatus */
							  FALSE,						  /* RxLineStatus */
							  TRUE,							  /* TxFifoEmpty */
							  TRUE,							  /* RxData */
							  E_AHI_UART_FIFO_LEVEL_1);

		return TRUE;
	}
	return FALSE;
}


PUBLIC void vUART_StartTx(void)
{
    /* Has interrupt driven transmit stalled (tx fifo is empty) */
    if (u8AHI_UartReadLineStatus(Serial_UART) & E_AHI_UART_LS_THRE)
    {
        if(!bSerialQ_Empty(TX_QUEUE))
        {
            vAHI_UartWriteData(Serial_UART, u8SerialQ_RemoveItem(TX_QUEUE));
        }
    }
}


PUBLIC void vUART_TxCharISR(uint8 u8Uart)
{
    if(!bSerialQ_Empty(TX_QUEUE))
	{
        vAHI_UartWriteData(u8Uart, u8SerialQ_RemoveItem(TX_QUEUE));
	}
}


PUBLIC void vUART_RxCharISR(uint8 u8RxChar)
{
    vSerialQ_AddItem(RX_QUEUE, u8RxChar);
}

#if UART_JENOS
OS_ISR(UART_vIsr0)
{
//	/* Have we opened UART0 ? */
//	if (Uart_Opened[0])
//	{
		uint8 u8IntStatus;

		u8IntStatus = u8AHI_UartReadInterruptStatus(E_AHI_UART_0);

		/* Pass on to full interrupt routine */
		UART_vInterrupt(E_AHI_DEVICE_UART0, ((u8IntStatus >> 1) & 0x7));
//	}
}
#endif

/****************************************************************************/
/**
 * <b>UART_vIsr1</b> &mdash; UART 1 interrupt service routine.
 */
/****************************************************************************/
#if UART_JENOS
OS_ISR(UART_vIsr1)
{
	/* Have we opened UART1 ? */
//	if (Uart_Opened[1])
//	{
		uint8 u8IntStatus;

		u8IntStatus = u8AHI_UartReadInterruptStatus(E_AHI_UART_1);


		/* Pass on to full interrupt routine */
		UART_vInterrupt(E_AHI_DEVICE_UART1, (u8IntStatus >> 1) & 0x7);

//	}
}
#endif

PUBLIC void UART_bPutChar (char cChar)					/**< Character to transmit */
{
	vSerialQ_AddItem(TX_QUEUE, (uint8) cChar);
	vUART_StartTx();
}



PRIVATE void UART_vInterrupt(uint32 u32Device, uint32 u32ItemBitmap)
{
	uint8 u8Uart = 0xFF;
	uint8 rxChar;
	APP_vLedsInitialise();
	/* Which uart ? */

//	if (u32Device == E_AHI_DEVICE_UART0) u8Uart = E_AHI_UART_0;
	if (u32Device == E_AHI_DEVICE_UART1) u8Uart = E_AHI_UART_1;

		if ((u32ItemBitmap & 0xFF) == E_AHI_UART_INT_RXDATA ||
			(u32ItemBitmap & 0xFF) == E_AHI_UART_INT_TIMEOUT)
	{
//		while (u8AHI_UartReadLineStatus(u8Uart) & E_AHI_UART_LS_DR)
//			{
//				APP_vLedSet(1, TRUE);
			rxChar= u8AHI_UartReadData(u8Uart);
			vUART_RxCharISR(rxChar);

	}
        else if ((u32ItemBitmap & 0xFF) == E_AHI_UART_INT_TX)
      {
        	APP_vLedSet(1, TRUE);
            vUART_TxCharISR(u8Uart);

        }
}


PUBLIC 	bool_t writeData (
			const char     *pcFormat,	/**< Formatting string */
		...)
{
	va_list ap;

	/* Initialise argument pointer */
	va_start(ap, pcFormat);
	/* Call the worker function to do the work */
	return UART_bPrintf_ap (pcFormat, ap);
}
PUBLIC 	bool_t UART_bPrintf_ap (const char     *pcFormat,	/**< Formatting string */
		va_list         ap)
{
//	/* Uart has been opened ? */
//	if (u8Uart < 2 && asUart[u8Uart].bOpened)
//	{
		char *bp = (char *)pcFormat;
		char c;
		char *p, *t;
		int32 i;
		uint8 u8Min, u8Len;
		char   cPad;
		char   cSign;
		bool_t bPrefix;
		bool_t bLeft;
		uint64 u64Address;

		while ((c = *bp++)) {
			if (c != '%') {
				UART_bPutChar(c);
				continue;
			}

			/* Flags ? */
			bPrefix = FALSE;
			bLeft   = FALSE;
			cSign   = 0;
			cPad   = ' ';
			while (*bp == '#' || *bp == '-' || *bp == '+' || *bp == ':' || *bp == ' ' || *bp == '0' || *bp == '_')
			{
				switch (*bp)
				{
				case '#': bPrefix = TRUE; break; /* Number base flag  */
				case '-': bLeft   = TRUE; break; /* left align flag  */
				case '+': cSign   = '+';  break; /* sign on positive number flag  */
				case ' ': cSign   = ' ';  break; /* space on positive number flag  */
				case ':': cSign   = ':';  break; /* colons in mac address flag */
				case '0': cPad    = '0';  break; /* pad with 0 flag  */
				case '_': cPad    = '_';  break; /* pad with underscore flag */
				}
				bp++;
			}

			/* Minimum width ? */
			u8Min = 0;
			if (*bp == '*')
			{
				u8Min = (uint8) va_arg(ap, uint32);
				bp++;
			}
			else
			{
				while (*bp >= '0' && *bp <= '9')
				{
					u8Min=u8Min*10+(*bp-'0');
					bp++;
				}
			}

			switch ((c = *bp++)) {

			/* %d - show a decimal value */
			case 'd':
				UART_bNum2String(va_arg(ap, uint32), 10, u8Min, cPad, bLeft, 0, bPrefix);
				break;

			/* %x - show a value in hex */
			case 'x':
				UART_bNum2String(va_arg(ap, uint32), 16, u8Min, cPad, bLeft, 0, bPrefix);
				break;

			/* %m - show mac address in hex */
			case 'm':
				if (cSign != ':') cSign = 0;
				u64Address = va_arg(ap, uint64);
				UART_bNum2String((uint32)(u64Address >> 32),        16, 8, '0', FALSE, cSign, bPrefix);
				if (cSign != 0)  UART_bPutChar(cSign);
				UART_bNum2String((uint32)(u64Address & 0xffffffff), 16, 8, '0', FALSE, cSign, FALSE);
				break;

			/* %b - show a value in binary */
			case 'b':
				UART_bNum2String(va_arg(ap, uint32), 2, u8Min, cPad, bLeft, cSign, bPrefix);
				break;

			case 'i':
				i = va_arg(ap, int32);
				if(i < 0){
					cSign = '-';
					UART_bNum2String((~i)+1, 10, u8Min, cPad, bLeft, cSign, bPrefix);
				} else {
					if (cSign == ':') cSign = 0;
					UART_bNum2String(i, 10, u8Min, cPad, bLeft, cSign, bPrefix);
				}
				break;

			/* %c - show a character */
			case 'c':
				UART_bPutChar(va_arg(ap, int));
				break;

			/* %s - show a string */
			case 's':
				p = va_arg(ap, char *);
				t = p;
				u8Len = 0;
				while (*t++) ++u8Len;
				if (!bLeft && u8Min>u8Len) UART_bPad2Min(0, u8Min-u8Len, cPad);
				do {
					UART_bPutChar(*p++);
				} while (*p);
				if (bLeft && u8Min>u8Len) UART_bPad2Min(u8Len, u8Min, cPad);
				break;

			/* %% - show a % character */
			case '%':
				UART_bPutChar('%');
				break;

			/* %something else not handled ! */
			default:
				UART_bPutChar('?');
				UART_bPutChar(c);
				break;
			}
		}

		/* If interrupts are not being serviced start transmitting */
		vUART_StartTx();

		return TRUE;
//	}
//	else
//	{
//		return FALSE;
//	}
}

/****************************************************************************/
/**
 * <b>UART_bPad2Min</b> &mdash; Convert a number to a string
 */
/****************************************************************************/
PRIVATE bool_t UART_bPad2Min(uint8 u8Width, uint8 u8Min, char cPad)
{
	/* Uart has been opened ? */

		while (u8Width < u8Min)
		{
			UART_bPutChar(cPad);
			u8Width++;
		}
		return TRUE;
	}

/****************************************************************************/
/**
 * <b>UART_bNum2String</b> &mdash; Convert a number to a string.
 */
/****************************************************************************/
PRIVATE bool_t UART_bNum2String(uint32 u32Number, uint8 u8Base, uint8 u8Min, char cPad, bool_t bLeft, char cSign, bool_t bPrefix)
{
	/* Uart has been opened ? */
		char buf[33];
		char *p = buf + 33;
		uint32 c, n;
		uint8 u8Width=0;
		uint8 u8Pos=0;

		if (u8Min > 32) u8Min=32;

		*--p = '\0';
		do {
			n = u32Number / u8Base;
			c = u32Number - (n * u8Base);
			if (c < 10) {
				*--p = '0' + c;
			} else {
				*--p = 'a' + (c - 10);
			}
			u32Number /= u8Base;
			u8Width++;
		} while (u32Number != 0);

		if (cPad == '0')
		{
			while (u8Width < u8Min)
			{
				*--p = '0';
				u8Width++;
			}
		}

		if (cPad != '0' && bLeft == FALSE)
		{
			UART_bPad2Min(u8Width, u8Min, cPad);
		}

		if(cSign != 0 && cSign != ':')  UART_bPutChar(cSign);

		if (bPrefix)
		{
			switch (u8Base)
			{
				case 16:
					UART_bPutChar('0');
					UART_bPutChar('x');
					break;
				case 2:
					UART_bPutChar('0');
					UART_bPutChar('b');
					break;
			}
		}

		while (*p){
			UART_bPutChar(*p);
			p++;
			if (cSign == ':')
			{
				if ((u8Pos%2)==1 && (*p))
				{
					UART_bPutChar(cSign);
				}
				u8Pos++;
			}
		}

		if (cPad != '0' && bLeft == TRUE)
		{
			UART_bPad2Min(u8Width, u8Min, cPad);
		}
		return TRUE;
	}
//	else
//	{
//		return FALSE;
//	}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
