#include <jendefs.h>
#include <AppHardwareApi.h>

#include "uart.h"
#include "serialq.h"
#include "serial.h"
#include "dbg.h"
#include "app_home_sensor_demo.h"
#include "app_log.h"
#include "app_display.h"
#include <stdlib.h>

#define TX_STRING_END_CHAR   '\0'    /* Strings to be transmitted must end with NULL */
#define RX_STRING_END_CHAR   CR_CHAR /* Input string must end with carriage return */



PUBLIC void vSerial_Init(void)
{
    /* Initialise the serial port and rx/tx queues */
    vSerialQ_Init();
    vUART_Init(Serial_UART, Serial_BAUD, Serial_EVEN, Serial_PARITY, Serial_WORDLEN, Serial_ONESTOP);
}
/****************************************************************************/

PUBLIC void vSerial_TxOutput(string u8Char)
{
	uint8 i;
	if (!bSerialQ_Full(TX_QUEUE)) {
		for (i = 0; i < vStrlen(u8Char) ; i++) {
			vSerialQ_AddItem(TX_QUEUE, u8Char[i]);
			vUART_StartTx(); /* Start the tx process if it has stalled */
		}
	}
}

/****************************************************************************/
PUBLIC void vSerial_TxChar(uint8 u8Char)
{
//	uint8 i;
	if (!bSerialQ_Full(TX_QUEUE)) {
//		for (i = 0; i < vStrlen(u8Char); i++) {
			vSerialQ_AddItem(TX_QUEUE, u8Char);
			vUART_StartTx(); /* Start the tx process if it has stalled */
//		}
	}
}

/****************************************************************************/

PUBLIC void vSerial_TxBuffer(uint8 *pb, uint16 u16Size)
{
//	uint16 u16Offset;
	uint16 i;

	if (!bSerialQ_Full(TX_QUEUE)) {
		for (i = 0; i < u16Size ; i++) {
			vSerialQ_AddItem(TX_QUEUE, pb[i]);
			vUART_StartTx(); /* Start the tx process if it has stalled */
		}
	}
}

/****************************************************************************/

PUBLIC int16 i16Serial_RxChar(void)
{
    int16 i16Result = -1;

    if(!bSerialQ_Empty(RX_QUEUE))
	{
   	    i16Result = u8SerialQ_RemoveItem(RX_QUEUE);
	}
    return(i16Result);
}

/****************************************************************************/

PUBLIC void vSerialRxString(uint8 *ps)
{
    uint8 *pu8String;
	int16 i16Chr;

    /* Copy the received string from the receive queue */

    for(pu8String = ps; ((i16Chr = i16Serial_RxChar()) != (int16)RX_STRING_END_CHAR); pu8String++)
    {
        *pu8String = (uint8)i16Chr;
    }

    *pu8String = (uint8)'\0'; /* Append NULL character to the end of the string */
}

/****************************************************************************/

PUBLIC void vSerialRxBuffer(uint8 *pb, uint16 u16Size)
{
    uint8 *pu8String;
	int16 i16Chr;
	uint16 offset;

    /* Copy the received string from the receive queue */

	pu8String = pb;
    for(offset = 0 ;  offset!=u16Size ; offset++)
    {
    	i16Chr = i16Serial_RxChar();
        pu8String[offset] = (uint8)i16Chr;
    }

}


/****************************************************************************
 *
 * NAME: Rfid_Rawread
 *
 * DESCRIPTION: Send the Read command to the RFID reader
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void Rfid_Rawread(void)
{
uint16 u16Char[] = {0x8001, 0x0000, 0x0000, 0x5358, 0x0021, 0x0000,
		0x0008, 0x0001, 0x0013, 0x0000, 0x000F, 0x00FB};
	int i;
	string src;
	for (i=0; i < 12; i++)
	{
		uint8 hi_temp, lo_temp;
		hi_temp = u16Char[i] ;
		lo_temp = u16Char[i]>>8;
		vSerial_TxChar(lo_temp);
		vSerial_TxChar(hi_temp);
	}

	src = "Source_0";
	vSerial_TxOutput(src);
	/* Start the tx process if it has stalled */
}

/****************************************************************************/
int vStrlen(char *s)
{
	   int c = 0;

	   while(*(s+c))
	      c++;

	   return c;
}
/****************************************************************************
 *
 * NAME: Rfid_Rawread
 *
 * DESCRIPTION: Send the Read command to the RFID reader
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/

PUBLIC void vSerial_SensorData()
{
	APP_tsLogNodeHistory *psNodeHistory;
	uint8 u8Node, i;
	uint8 u8CurTemp, u8CurHum, u8CurLight, Addr1, Addr2, TagID[12];
	uint16 u16ShtAddr;
//	uint8 seqno;
//	if(seq != 0)
//	{
//
//	}

	if (APP_u8ControllerNodeNumDataSensors() != 0)
	{
		for (u8Node = 0; u8Node < APP_u8ControllerNodeNumDataSensors(); u8Node++)
		{
			psNodeHistory = APP_psLogGetSensorNodeHistory(u8Node);
			u8CurTemp = psNodeHistory->asNodeSensorData[APP_E_SENSOR_TEMP].u8NowValue;
			u8CurHum =  psNodeHistory->asNodeSensorData[APP_E_SENSOR_HTS].u8NowValue;
			u8CurLight = psNodeHistory->asNodeSensorData[APP_E_SENSOR_ALS].u8NowValue;
			u16ShtAddr = psNodeHistory->u16ShortAddr;
			for (i=0; i<12;i++)
			{
			TagID[i]= psNodeHistory->u8aRfidTagid[i];
			}
			Addr1 = u16ShtAddr >>8;
			Addr2 = u16ShtAddr;
			uint8 msgId = u8Node+1;
			uint8 NodeNum = APP_u8ControllerNodeNumDataSensors();
			writeData("%d|%d|%02x%02x|%d|%d|%d|", msgId, NodeNum, Addr1, Addr2, u8CurTemp, u8CurHum, u8CurLight);
			for (i=0; i<11;i++)
						{
				writeData("%02x", TagID[i]);
						}
			writeData("%02x|", TagID[11]);
		}
//		seqq++;

	}
	writeData("\n");
}
/****************************************************************************
 *
 * NAME: GetRFID
 *
 * DESCRIPTION: Process the RFID response from the queue
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void  GetRFID(void)
{
//	unsigned int t =0;
	uint8 data[200];
	uint8 i = 0;
	uint16 byte2;
	uint8 byte3;
	int b,jj;
	int a = 0, c = 0;
	if (bSerialQ_Empty(RX_QUEUE))
	{
		DBG_vPrintf(TRACE_APP,"\n\r queue empty \n\r");
		DBG_vPrintf(TRACE_APP,"\n\r No RFID Reader detected \n\r");
			for (i=0; i<12; i++)
			{
				id[i] = 0x00;
			}
			for (i=0; i<12; i++)
			{
			DBG_vPrintf(TRACE_APP,"\n\r dummy values of id[a12]: %02x \n\r", id[i]);
			}

			return;
	}
	else
	{
	while(!bSerialQ_Empty(RX_QUEUE))
       {
		data[i] = u8SerialQ_RemoveItem(RX_QUEUE);
		i++;
       }
	b=i;
	vSerialQ_Flush(RX_QUEUE);

	b=i;
	for (jj=0;jj<i;jj++)
	{
		DBG_vPrintf(TRACE_APP,"\n\r %02x \n\r", data[jj]);
	}
	for (i=0; i < b; i++)
	{
		if(data[i] == 0x00 && data[i+1]==0x01 && data[i+6] == 0x53 && data[i+7]==0x58)
		{
		a=i+80;
		c=i;
		break;
		}
		else
		{
			DBG_vPrintf(TRACE_APP,"\n\r No tag detected \n\r");
					for (i=0; i<12; i++)
					{
						id[i] = 0x11;
					}
		}
	}

	byte2 = data[c+23] | data[c+24];
	byte3 = data[c+25];
	DBG_vPrintf(TRACE_APP,"\n\r id[code]: %0x : %0x \n\r", data[c+23], data[c+24]);
	if (byte2 == 0x0002 && byte3 == 0x00)
	{
		DBG_vPrintf(TRACE_APP,"\n\r No tag detected \n\r");
		for (i=0; i<12; i++)
		{
			id[i] = 0x11;
		}
		for (i=0; i<12; i++)
				{
				DBG_vPrintf(TRACE_APP,"\n\r dummy values of id[a12]: %02x \t\r", id[i]);
				}
		return;
	}

	else
	{
	int j=0;
	for (i=a; i<=(a+12); i++)
	{
		id[j] = data[i];
		j++;
	}
	DBG_vPrintf(TRACE_APP,"\n\r RFID extracted \n\r");
	for (i=0; i<12; i++)
		{

					DBG_vPrintf(TRACE_APP,"\n\r id[a12]: %0x \t\r", id[i]);
		}
	return;
	}

}
}
/****************************************************************************
 *
 * NAME: vDelayMsec
 *
 * DESCRIPTION: Function to create delay
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vDelayMsec(uint32 u32Period)
{
    uint32 i, k;
    const uint32 u32MsecCount = 1800;
    volatile uint32 j;
    /* declare as volatile so compiler doesn't optimise increment away */

    for (k = 0; k < u32Period; k++)
        for (i = 0; i < u32MsecCount; i++) j++;
}


/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
