#ifndef  CONFIG_H_INCLUDED
#define  CONFIG_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

#include <jendefs.h>

/* Network parameters */
#define PAN_ID                  0xDEA1U
#define COORD_ADDR              0x0000U

/* Wireless UART device data */
#define MAX_UART_NODES          1
#define UART_NODE_ADDR_BASE     0x0001U
#define MAX_DATA_PER_FRAME      64

#define TICK_PERIOD_ms          10UL
#define TICK_PERIOD_COUNT       (16000UL * TICK_PERIOD_ms)

/* Defines the channels to scan. Each bit represents one channel. All channels
   in the channels (11-26) in the 2.4GHz band are scanned. */
#define SCAN_CHANNELS           0x07FFF800UL
#define CHANNEL_MIN             11
#define ACTIVE_SCAN_DURATION    3
#define ENERGY_SCAN_DURATION    3 /* Duration (ms) = ((960 * (2^ENERGY_SCAN_DURATION + 1)) / 62.5) */

/* Define which of the two available hardware UARTs and what baud rate to use */
//#define UART                    E_AHI_UART_0
//#define UART_BAUD_RATE          19200


#if defined __cplusplus
}
#endif

#endif  /* CONFIG_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


