#ifndef APP_DISPLAY_H_
#define APP_DISPLAY_H_
/****************************************************************************/

typedef enum
{
    APP_E_DISPLAY_STATE_INIT,
    APP_E_DISPLAY_STATE_SPLASH,
    APP_E_DISPLAY_STATE_NETWORK_STARTUP,
    APP_E_DISPLAY_STATE_NETWORK,
    APP_E_DISPLAY_STATE_NODE
} APP_teDisplayState;

/****************************************************************************/

PUBLIC void APP_vDisplayInitialise(void);
PUBLIC void APP_vDisplayCycleNode(void);
PUBLIC void APP_vDisplayUpdate(void);
PUBLIC uint8 APP_u8GetCurrentNode(void);
PUBLIC void vValToDec(char *pcOutString, uint8 u8Value, char *pcLabel);
PUBLIC void vStringCopy(char *pcFrom, char *pcTo);

/****************************************************************************/

extern APP_teDisplayState app_eDisplayState;
extern APP_teSensor app_eCurrentSensor;

/****************************************************************************/

/****************************************************************************
 *
 * NAME: APP_vDisplaySetState
 *
 * DESCRIPTION:
 * Sets the display state
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
static inline void APP_vDisplaySetState(APP_teDisplayState eDisplayState)
{
    app_eDisplayState = eDisplayState;
}

/****************************************************************************
 *
 * NAME: APP_vDisplaySetSensor
 *
 * DESCRIPTION:
 * Sets the displayed sensor
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
static inline void APP_vDisplaySetSensor(APP_teSensor eSensor)
{
    app_eCurrentSensor = eSensor;
}


#endif /*APP_DISPLAY_H_*/
