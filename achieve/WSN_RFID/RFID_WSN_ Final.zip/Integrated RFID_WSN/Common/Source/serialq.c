
#include <jendefs.h>
#include <AppHardwareApi.h>
#include <os.h>
#include "os_gen.h"

#include "serialq.h"


#define CIRCBUFF_PTR_MASK   0x03FFU
#define MAX_CIRCBUFF_SIZE   1024
#define NBR_QUEUES          2

typedef struct
{
    uint16 u16Head;
    uint16 u16Tail;
    uint8  u8Buff[MAX_CIRCBUFF_SIZE];
} tsCircBuff;


PRIVATE tsCircBuff sRxQueue, sTxQueue;
PRIVATE const tsCircBuff *apsQueueList[NBR_QUEUES] = { &sRxQueue, &sTxQueue };


//PRIVATE void vSerialQ_Flush(eQueueRef eQueue);


PUBLIC void vSerialQ_Init(void)
{
    vSerialQ_Flush(RX_QUEUE);
    vSerialQ_Flush(TX_QUEUE);
}


PUBLIC void vSerialQ_AddItem(eQueueRef eQueue, uint8 u8Item)
{
    tsCircBuff *psQueue;
    uint16 u16NextLocation;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    u16NextLocation = (psQueue->u16Head + 1) & CIRCBUFF_PTR_MASK;

    if (u16NextLocation != psQueue->u16Tail)
    {
        /* Space available in buffer so add data */
        psQueue->u8Buff[psQueue->u16Head] = u8Item;
        psQueue->u16Head = u16NextLocation;
    }
}


PUBLIC uint8 u8SerialQ_RemoveItem(eQueueRef eQueue)
{
    uint8 u8Item = 0;
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    if (psQueue->u16Tail != psQueue->u16Head)
    {
        /* Data available on queue so remove a single item */
        u8Item = psQueue->u8Buff[psQueue->u16Tail];
        psQueue->u16Tail = (psQueue->u16Tail + 1) & CIRCBUFF_PTR_MASK;
    }
    return(u8Item);
}


PUBLIC bool_t bSerialQ_Empty(eQueueRef eQueue)
{
    bool_t bResult = FALSE;
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue];

    if (psQueue->u16Tail == psQueue->u16Head)
    {
        bResult = TRUE;
    }
    return(bResult);
}

PUBLIC bool_t bSerialQ_Full(eQueueRef eQueue)
{
    bool_t bResult = FALSE;
    tsCircBuff *psQueue;
    uint16 u16NextLocation;

    psQueue = (tsCircBuff *)apsQueueList[eQueue];

    u16NextLocation = (psQueue->u16Head + 1) & CIRCBUFF_PTR_MASK;

    if (u16NextLocation == psQueue->u16Tail)
    {
	    bResult = TRUE;
    }
    return(bResult);
}


PUBLIC void vSerialQ_Flush(eQueueRef eQueue)
{
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    psQueue->u16Head  = 0;
    psQueue->u16Tail  = 0;
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
