#ifndef APP_LED_H_
#define APP_LED_H_

/****************************************************************************/
PUBLIC void APP_vLedsInitialise(void);
PUBLIC void APP_vLedSet(uint8 u8Led, bool_t bOn);
/****************************************************************************/

#endif /*APP_LED_H_*/
