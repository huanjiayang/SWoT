/****************************************************************************/

#include <jendefs.h>
#include "os.h"
#include "os_gen.h"
#include "DBG.h"
#include "pwrm.h"
#include "AppHardwareApi.h"
#include "app_home_sensor_demo.h"
#include "app_timer_driver.h"
#include "app_buttons.h"
#include "HtsDriver.h"

#ifndef TRACE_APP_SYSCON
#define TRACE_APP_SYSCON            FALSE
#endif

/****************************************************************************
 *
 * NAME: APP_SysConISR
 *
 * DESCRIPTION:
 * Interrupt
 *
 ****************************************************************************/
OS_ISR(APP_isrSysCon)
{
    /* clear pending DIO changed bits by reading register */
    uint32 u32IntSource = u32AHI_DioInterruptStatus();
    uint8 u8WakeInt = u8AHI_WakeTimerFiredStatus();

    if (u8WakeInt & E_AHI_WAKE_TIMER_MASK_1)
    {
        /* wake timer interrupt got us here */
        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Wake Timer 1 Interrupt\n");
        PWRM_vWakeInterruptCallback();
    }
    else if (u8WakeInt & E_AHI_WAKE_TIMER_MASK_0)
    {
        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Wake Timer 0 Interrupt\n");
    }

    if (u32IntSource & HTS_DATA_DIO_BIT_MASK)
    {
        /* Disable further interrupts */
        vAHI_DioInterruptEnable(0, HTS_DATA_DIO_BIT_MASK);

        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Sample ready\r\n");

        /* activate task to sample sensors now sample is ready */
        OS_eActivateTask(APP_taskSampleSensors);
    }

    if (u32IntSource & APP_BUTTONS_DIO_MASK)
    {
        /* disable edge detection until scan complete */
        vAHI_DioInterruptEnable(0, APP_BUTTONS_DIO_MASK);

        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Button press\r\n");

        OS_eStartSWTimer(APP_tmrButtonsScan, APP_TIME_MS(5), NULL);
    }
}

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
