/****************************************************************************/
#include <jendefs.h>
#include "os.h"
#include "os_gen.h"
#include "DBG.h"
#include "pwrm.h"
#include "AppHardwareApi.h"
#include "app_home_sensor_demo.h"
#include "app_timer_driver.h"
#include "app_buttons.h"
#include "HtsDriver.h"

#if OVERLAYS_BUILD
#include "ovly.h"
#endif
/****************************************************************************/

#ifndef TRACE_APP_SYSCON
#define TRACE_APP_SYSCON            FALSE
#endif
/****************************************************************************/
extern bool bOvlyInit;
/****************************************************************************/
/****************************************************************************
 *
 * NAME: APP_SysConISR
 *
 * DESCRIPTION:
 * Interrupt
 *
 ****************************************************************************/
OS_ISR(APP_isrSysCon)
{
#if OVERLAYS_BUILD
    if (!bOvlyInit) {
        OVLY_vReInit();
        bOvlyInit = TRUE;
    }
#endif
    /* clear pending DIO changed bits by reading register */
    uint32 u32IntSource = u32AHI_DioInterruptStatus();
    uint8 u8WakeInt = u8AHI_WakeTimerFiredStatus();

    DBG_vPrintf(TRACE_APP_SYSCON, "APP: DIO_Status: %x \r\n", u32IntSource );

    if (u8WakeInt & E_AHI_WAKE_TIMER_MASK_1)
    {
        /* wake timer interrupt got us here */
        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Wake Timer 1 Interrupt\n");
        PWRM_vWakeInterruptCallback();
    }

    if (u32IntSource & HTS_DATA_DIO_BIT_MASK)
    {
        /* Disable further interrupts */
        vAHI_DioInterruptEnable(0, HTS_DATA_DIO_BIT_MASK);

        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Sample ready\r\n");

        /* activate task to sample sensors now sample is ready */
        OS_eActivateTask(APP_taskSampleSensors);
    }


    if (u32IntSource & APP_BUTTONS_DIO_MASK)
    {
        DBG_vPrintf(TRACE_APP_SYSCON, "APP: Button Push\r\n");

        /* disable edge detection until scan complete */
        vAHI_DioInterruptEnable(0, APP_BUTTONS_DIO_MASK);

        OS_eStartSWTimer(APP_tmrButtonsScan, APP_TIME_MS(5), NULL);
    }
}

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
