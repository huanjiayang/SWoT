#ifndef APP_SENSOR_NODE_SED_H_
#define APP_SENSOR_NODE_SED_H_

/****************************************************************************/
PUBLIC void APP_vInitialiseSensorNode(void);
PUBLIC uint8 APP_u8GetSequenceNumber(bool_t bInc);

/****************************************************************************/

#endif /*APP_SENSOR_NODE_SED_H_*/
