/****************************************************************************/

#include <jendefs.h>
#include "os.h"
#include "os_gen.h"

#include "DBG.h"
#include "AppHardwareApi.h"
#include "app_home_sensor_demo.h"
#include "zps_apl_af.h"
#include "ledcontrol.h"
#include "app_led.h"

/****************************************************************************/

#ifndef TRACE_APP_LED
#define TRACE_APP_LED               FALSE
#endif


/****************************************************************************
 *
 * NAME: APP_vLedsInitialise
 *
 * DESCRIPTION:
 * Initialises LEDs and sets them off
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void APP_vLedsInitialise(void)
{
    /* UARTs share DIO with LEDs - must disable RTS and CTS lines to prevent interference  */
    vAHI_UartSetRTSCTS(0, 0);
    vAHI_UartSetRTSCTS(1, 0);
    vLedInitRfd();
    vLedControl(0, 0);
    vLedControl(1, 0);
}

/****************************************************************************
 *
 * NAME: APP_vLedSet
 *
 * DESCRIPTION:
 * Turns specified LED on or off
 *
 * PARAMETERS:      Name        RW  Usage
 *                  u8Led       R   Identifies LED
 *                  bOn         R   TRUE = ON
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void APP_vLedSet(uint8 u8Led, bool_t bOn)
{
    vLedControl(u8Led, bOn);
}

/****************************************************************************
 *
 * NAME: APP_taskLedControl
 *
 * DESCRIPTION:
 * Receives LED control messages and turns LEDs on/off as necessary
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
OS_TASK(APP_taskLedControl)
{
    ZPS_tsAfEvent sLedEvent;
    DBG_vPrintf(TRACE_APP_LED, "APP_taskLedControl\n");

    /* collect the message for the LED control endpoint */
    if (OS_E_OK == OS_eCollectMessage(APP_msgLedEvent, &sLedEvent))
    {
        /* Ensure that we are dealing with a data indication - note that
         * data confirmations for this endpoint will also be received in this task
         */
        if (ZPS_EVENT_APS_DATA_INDICATION == sLedEvent.eType)
        {
            uint8 u8LedState;
            if (0 != PDUM_u16APduInstanceReadNBO(sLedEvent.uEvent.sApsDataIndEvent.hAPduInst,
                                                   APDU_LEDCTRL_STATE,
                                                   "b",
                                                   &u8LedState))
            {
                if (0 == sLedEvent.uEvent.sApsDataIndEvent.uSrcAddress.u16Addr)
                {
                    vLedControl(0, u8LedState);
                }
            }
            PDUM_eAPduFreeAPduInstance(sLedEvent.uEvent.sApsDataIndEvent.hAPduInst);
        }
    }
}

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
