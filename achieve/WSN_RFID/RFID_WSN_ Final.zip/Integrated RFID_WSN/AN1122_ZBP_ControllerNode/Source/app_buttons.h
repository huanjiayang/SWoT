/****************************************************************************/
/****************************************************************************/
#ifndef APP_BUTTONS_H
#define APP_BUTTONS_H

#define APP_CONTROLLER

/****************************************************************************/

#define APP_BUTTON_DECLARE(dio) \
    APP_tsButtonDescriptor app_sButton_##name = { NULL, dio, 0 };

#define APP_BUTTONS_BUTTON_1        (9)
#define APP_BUTTONS_BUTTON_2        (10)
#define APP_BUTTONS_BUTTON_3        (11)
#define APP_BUTTONS_BUTTON_4        (20)

#ifdef APP_CONTROLLER
#define APP_BUTTONS_NUM             (4UL)
#define APP_BUTTONS_DIO_MASK ( \
    (1 << APP_BUTTONS_BUTTON_1) | \
    (1 << APP_BUTTONS_BUTTON_2) | \
    (1 << APP_BUTTONS_BUTTON_3) | \
    (1 << APP_BUTTONS_BUTTON_4) )
#else
#define APP_BUTTONS_NUM             (2UL)
#define APP_BUTTONS_DIO_MASK ( \
    (1 << APP_BUTTONS_BUTTON_1) | \
    (1 << APP_BUTTONS_BUTTON_2))
#endif

/****************************************************************************/

typedef enum
{
    APP_E_BUTTONS_BUTTON_1 = 0,
    APP_E_BUTTONS_BUTTON_2,
    APP_E_BUTTONS_BUTTON_3,
    APP_E_BUTTONS_BUTTON_4
} APP_teButtons;

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
PUBLIC bool_t APP_bButtonInitialise(void);

/****************************************************************************/

#endif /*APP_BUTTONS_H*/
