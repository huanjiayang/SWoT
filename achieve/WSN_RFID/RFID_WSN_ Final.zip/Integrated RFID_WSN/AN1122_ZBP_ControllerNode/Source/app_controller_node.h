/****************************************************************************/

#ifndef APP_COORD_H_
#define APP_COORD_H_
/****************************************************************************/
PUBLIC void APP_vInitialiseControllerNode(void);
PUBLIC uint8 APP_u8ControllerNodeGetCurRadioChan(void);
PUBLIC uint8 APP_u8ControllerNodeNumAssociatedSensors(void);
PUBLIC uint8 APP_u8ControllerNodeNumDataSensors(void);
PUBLIC bool_t APP_bGetPermitJoining(void);
PUBLIC void APP_vSetPermitJoining(bool_t bPermit);

/****************************************************************************/
/***        External Variables                                            ***/
/****************************************************************************/

extern bool_t APP_bAppHealthy;

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

#endif /*APP_COORD_H_*/
